/*
 * Solution_CIP.c
 * This is the solution project for the training "Core Independent Peripherals on AVR":http://ww1.microchip.com/downloads/en/DeviceDoc/00002449A.pdf
 * Created: 26.09.2017 10:08:18
 * Author : M43914
 */ 


#include <avr/io.h>
#include <avr/interrupt.h>


#define ADC_ADMUX_ADC0 0
#define ADC_ADMUX_ADC1 1
//...
#define ADC_ADMUX_TEMP 8

#define ADC_PRESCALER_DIV_16  4
#define ADC_PRESCALER_DIV_32  5
#define ADC_PRESCALER_DIV_64  6
#define ADC_PRESCALER_DIV_128 7

#define ADC_ADMUX_REFS_AREF 0
#define ADC_ADMUX_REFS_AVCC 1
#define ADC_ADMUX_REFS_INT_1_1V 3

#define ADC_ADCSRB_AUTO_TRIGGER_FREE_RUN 0
#define ADC_ADCSRB_AUTO_TRIGGER_AC       1
#define ADC_ADCSRB_AUTO_TRIGGER_EXTINT0  2
#define ADC_ADCSRB_AUTO_TRIGGER_TC0_CM   3
#define ADC_ADCSRB_AUTO_TRIGGER_TC0_OVF  4
#define ADC_ADCSRB_AUTO_TRIGGER_TC1_CM   5
#define ADC_ADCSRB_AUTO_TRIGGER_TC1_OVF  6
#define ADC_ADCSRB_AUTO_TRIGGER_TC1_CE   7

#define TC_PRESCALER_DIV_1024 5

volatile int16_t temperature = 0;

ISR(ADC_vect)
{
	// Calculate the temperature in C
	temperature = (ADC - 247)/1.22;
	
	//PORTB |= (1 << PINB5);
	// Set PORTB5 low
	PORTB &= ~(1 << PINB5);
	
	// Clear the input capture flag in the TC1
	TIFR1 = (1 << ICF1);
}

ISR(TIMER1_CAPT_vect)
{
	// Set PORTB5 high
	PORTB |= (1 << PINB5);
}

static void InitADC(void)
{
	// Select internal 1.1 V reference, and tempsensor as input
	ADMUX = (ADC_ADMUX_REFS_INT_1_1V << REFS0) | (ADC_ADMUX_TEMP << MUX0);
	// Set prescaler to 1024, enable interrupts (clear flag) and enable ADC
	ADCSRA = (1 << ADEN) | (1 << ADATE) | (1 << ADIF) | (1 << ADIE) | (ADC_PRESCALER_DIV_128 << ADPS0);
	// Set ADC trigger source to TC1 Capture Event
	ADCSRB = (ADC_ADCSRB_AUTO_TRIGGER_TC1_CE << ADTS0);
}

static void InitTC1(void)
{
	// Set wave generation mode CTC with ICR1 as top value and prescaler to 1024
	TCCR1B = (1 << WGM12) | (1 << WGM13) | (TC_PRESCALER_DIV_1024 << CS10);
	// Enable input capture flag
	TIMSK1 = (1 << ICIE1);
	
	// Set timeout to 1s
	ICR1 = 15625;
}

int main(void)
{
	// Set PORTB5 as output
	DDRB |= (1 << PINB5);
	
	InitADC();
	
	sei();
	
	InitTC1();
	
	while (1)
	{
	}
}
